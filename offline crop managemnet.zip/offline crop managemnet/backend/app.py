from flask import Flask, jsonify, send_from_directory
import os, json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, "..", "frontend")
DATA_DIR = os.path.join(BASE_DIR, "data")

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")

# ---------------- PAGES ----------------

@app.route("/")
def home_page():
    return send_from_directory(FRONTEND_DIR, "home.html")


@app.route("/login")
def login_page():
    return send_from_directory(FRONTEND_DIR, "login.html")

@app.route("/soil")
def soil_page():
    return send_from_directory(FRONTEND_DIR, "soil.html")

@app.route("/crops")
def crops_page():
    return send_from_directory(FRONTEND_DIR, "crops.html")

@app.route("/planner")
def planner_page():
    return send_from_directory(FRONTEND_DIR, "planner.html")

# ---------------- APIs ----------------

@app.route("/api/soils")
def api_soils():
    with open(os.path.join(DATA_DIR, "soils.json"), encoding="utf-8") as f:
        soils = json.load(f)
    return jsonify(soils)

@app.route("/api/crops/<int:soil_id>")
def api_crops(soil_id):
    with open(os.path.join(DATA_DIR, "crops.json"), encoding="utf-8") as f:
        crops = json.load(f)

    result = [c["name"] for c in crops if c["soil_id"] == soil_id]
    return jsonify(result)

@app.route("/api/planner/<crop_name>")
def api_planner(crop_name):
    with open(os.path.join(DATA_DIR, "planner.json"), encoding="utf-8") as f:
        plans = json.load(f)

    for p in plans:
        if p["crop"].lower() == crop_name.lower():
            return jsonify(p)

    return jsonify({})

# ---------------- RUN ----------------

if __name__ == "__main__":
    app.run(debug=True)
