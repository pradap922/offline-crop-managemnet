import sqlite3
import os

# ✅ absolute DB path (VERY IMPORTANT)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "data", "crop_planner.db")

def get_connection():
    return sqlite3.connect(DB_PATH)

def get_soils():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, name, characteristics FROM soils")
    rows = cur.fetchall()
    conn.close()
    return rows

def get_crops_by_soil(soil_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT id, name, image FROM crops WHERE soil_id=?",
        (soil_id,)
    )
    rows = cur.fetchall()
    conn.close()
    return rows

def get_crop_plan(crop_id):
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        SELECT sowing_method, duration_days, water_level,
               irrigation_interval, sowing_date
        FROM crop_plans
        WHERE crop_id=?
    """, (crop_id,))
    plan = cur.fetchone()

    cur.execute("""
        SELECT day, fertilizer_name
        FROM fertilizers
        WHERE crop_id=?
        ORDER BY day
    """, (crop_id,))
    fertilizers = cur.fetchall()

    conn.close()
    return plan, fertilizers
