from datetime import datetime,timedelta
from database import get_crop_plan
def generate_plan(c):
 p,f=get_crop_plan(c)
 sd=datetime.strptime(p[4],'%Y-%m-%d')
 return {
  'sowing':p[0],
  'duration':p[1],
  'water':p[2],
  'harvest_date':(sd+timedelta(days=p[1])).strftime('%d-%b-%Y')
 }