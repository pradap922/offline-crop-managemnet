const soilId = localStorage.getItem("soil_id");
const box = document.getElementById("crops");

fetch(`/api/crops/${soilId}`)
  .then(res => res.json())
  .then(data => {
    box.innerHTML = "";

    data.forEach(crop => {
      const imgName = crop.toLowerCase().replaceAll(" ", "_");

      const card = document.createElement("div");
      card.className = "card";

      card.innerHTML = `
        <img src="assets/crops/${imgName}.jpg"
             onerror="this.src='assets/crops/default.jpg'">
        <div class="label">
        <h3>${crop}</h3>
        </div>

      `;

      card.onclick = () => {
        localStorage.setItem("crop_name", crop);
        location.href = "/planner";
      };

      box.appendChild(card);
    });
  });
