fetch("/api/soils")
  .then(res => res.json())
  .then(data => {
    const box = document.getElementById("soils");
    box.innerHTML = "";

    data.forEach(soil => {
      const imgName = soil.name
        .toLowerCase()
        .replaceAll(" ", "_");

      const card = document.createElement("div");
      card.className = "card";

      card.innerHTML = `
        <img src="assets/soils/${imgName}.jpg"
             onerror="this.src='assets/soils/default.jpg'">

        <div class="label">
          <h3>${soil.name}</h3>
        </div>

        <p class="desc">${soil.characteristics}</p>
      `;

      card.onclick = () => {
        localStorage.setItem("soil_id", soil.id);
        location.href = "/crops";
      };

      box.appendChild(card);
    });
  });
