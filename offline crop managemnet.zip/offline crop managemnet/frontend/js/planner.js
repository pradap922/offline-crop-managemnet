const crop = localStorage.getItem("crop_name");

if (!crop) {
  document.getElementById("content").innerHTML =
    "<p>No crop selected.</p>";
} else {
  fetch(`/api/planner/${crop}`)
    .then(res => res.json())
    .then(p => {
      if (!p.crop) {
        document.getElementById("content").innerHTML =
          "<p>No plan found for selected crop.</p>";
        return;
      }

      document.getElementById("content").innerHTML = `
        <h3>${p.crop}</h3>
        <p><b>Sowing Method:</b> ${p.sowing_method}</p>
        <p><b>Crop Period:</b> ${p.crop_period} days</p>
        <p><b>Fertilizer:</b> ${p.fertilizer}</p>
        <p><b>Water Level:</b> ${p.water_level}</p>
        <p><b>Harvest Time:</b> ${p.harvest_time}</p>
        <p><b>Irrigation Interval:</b> Every ${p.irrigation_interval} days</p>
      `;
    });
}
